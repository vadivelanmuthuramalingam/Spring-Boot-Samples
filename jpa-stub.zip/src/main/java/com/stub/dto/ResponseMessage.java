package com.stub.dto;

public class ResponseMessage {

}
