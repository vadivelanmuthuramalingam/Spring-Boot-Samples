package com.stub.dto;

public class RequestMessage {

}
